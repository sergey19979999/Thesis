testSeedR <- function(){
	seed = get_seed()
	testSeed(seed)
}