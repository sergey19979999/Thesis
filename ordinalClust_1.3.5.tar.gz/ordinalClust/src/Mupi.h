#pragma once
class Mupi
{
public:
	Mupi(double pi, int mu);
	Mupi();
	~Mupi();
	double _pi;
	int _mu;
};

