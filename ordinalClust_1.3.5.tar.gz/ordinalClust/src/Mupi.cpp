#include "Mupi.h"


Mupi::Mupi(double pi, int mu)
{
	this->_mu = mu;
	this->_pi = pi;
}
Mupi::Mupi()
{
}


Mupi::~Mupi()
{
}

