#pragma once
class LogProbs
{
public:
	LogProbs(double row, double col);
	LogProbs();
	~LogProbs();
	double _row;
	double _col;
};

